#!/bin/bash
cd /home/ubuntu
docker-compose --file docker-compose.production.yml up -d